import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_bike_vendor_detailse_page_screen/models/ev_bike_vendor_detailse_page_model.dart';/// A provider class for the EvBikeVendorDetailsePageScreen.
///
/// This provider manages the state of the EvBikeVendorDetailsePageScreen, including the
/// current evBikeVendorDetailsePageModelObj

// ignore_for_file: must_be_immutable
class EvBikeVendorDetailsePageProvider extends ChangeNotifier {EvBikeVendorDetailsePageModel evBikeVendorDetailsePageModelObj = EvBikeVendorDetailsePageModel();

@override void dispose() { super.dispose(); } 
 }
