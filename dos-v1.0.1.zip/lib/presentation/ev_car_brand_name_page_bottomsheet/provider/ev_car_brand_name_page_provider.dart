import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_car_brand_name_page_bottomsheet/models/ev_car_brand_name_page_model.dart';import '../models/carbrandselector_item_model.dart';/// A provider class for the EvCarBrandNamePageBottomsheet.
///
/// This provider manages the state of the EvCarBrandNamePageBottomsheet, including the
/// current evCarBrandNamePageModelObj

// ignore_for_file: must_be_immutable
class EvCarBrandNamePageProvider extends ChangeNotifier {EvCarBrandNamePageModel evCarBrandNamePageModelObj = EvCarBrandNamePageModel();

@override void dispose() { super.dispose(); } 
void changeRadioButton1(int index, String value, ) { evCarBrandNamePageModelObj.carbrandselectorItemList[index].radioGroup = value; notifyListeners(); } 
void changeRadioButton2(int index, String value, ) { evCarBrandNamePageModelObj.carbrandselectorItemList[index].radioGroup1 = value; notifyListeners(); } 
 }
