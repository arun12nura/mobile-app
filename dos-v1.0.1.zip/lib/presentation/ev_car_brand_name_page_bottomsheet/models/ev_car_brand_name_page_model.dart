import 'carbrandselector_item_model.dart';import '../../../core/app_export.dart';class EvCarBrandNamePageModel {List<CarbrandselectorItemModel> carbrandselectorItemList = List.generate(2,(index) => CarbrandselectorItemModel());

 }
