import '../../../core/app_export.dart';class BikeBrandNamePageModel {List<String> radioList = ["lbl_yamaha","lbl_honda"];

 }
