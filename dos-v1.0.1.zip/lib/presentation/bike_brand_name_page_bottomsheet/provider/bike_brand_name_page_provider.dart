import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/bike_brand_name_page_bottomsheet/models/bike_brand_name_page_model.dart';/// A provider class for the BikeBrandNamePageBottomsheet.
///
/// This provider manages the state of the BikeBrandNamePageBottomsheet, including the
/// current bikeBrandNamePageModelObj

// ignore_for_file: must_be_immutable
class BikeBrandNamePageProvider extends ChangeNotifier {BikeBrandNamePageModel bikeBrandNamePageModelObj = BikeBrandNamePageModel();

String radioGroup = "";

String brandName = "";

@override void dispose() { super.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
void changeRadioButton2(String value) { brandName = value; notifyListeners(); } 
 }
