import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_issue_page_one_bottomsheet/models/laptop_issue_page_one_model.dart';/// A provider class for the LaptopIssuePageOneBottomsheet.
///
/// This provider manages the state of the LaptopIssuePageOneBottomsheet, including the
/// current laptopIssuePageOneModelObj

// ignore_for_file: must_be_immutable
class LaptopIssuePageOneProvider extends ChangeNotifier {TextEditingController issuesController = TextEditingController();

LaptopIssuePageOneModel laptopIssuePageOneModelObj = LaptopIssuePageOneModel();

String radioGroup = "";

@override void dispose() { super.dispose(); issuesController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
 }
