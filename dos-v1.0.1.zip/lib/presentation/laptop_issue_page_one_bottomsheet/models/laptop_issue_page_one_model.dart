import '../../../core/app_export.dart';class LaptopIssuePageOneModel {List<String> radioList = ["lbl_laptop","lbl_computer"];

 }
