import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_bike_brand_name_page_bottomsheet/models/ev_bike_brand_name_page_model.dart';import '../models/evbikebrandnamepage_item_model.dart';/// A provider class for the EvBikeBrandNamePageBottomsheet.
///
/// This provider manages the state of the EvBikeBrandNamePageBottomsheet, including the
/// current evBikeBrandNamePageModelObj

// ignore_for_file: must_be_immutable
class EvBikeBrandNamePageProvider extends ChangeNotifier {EvBikeBrandNamePageModel evBikeBrandNamePageModelObj = EvBikeBrandNamePageModel();

@override void dispose() { super.dispose(); } 
void changeRadioButton1(int index, String value, ) { evBikeBrandNamePageModelObj.evbikebrandnamepageItemList[index].radioGroup = value;notifyListeners(); } 
void changeRadioButton2(int index, String value, ) { evBikeBrandNamePageModelObj.evbikebrandnamepageItemList[index].radioGroup1 = value;notifyListeners(); } 
 }
