import 'evbikebrandnamepage_item_model.dart';import '../../../core/app_export.dart';class EvBikeBrandNamePageModel {List<EvbikebrandnamepageItemModel> evbikebrandnamepageItemList = List.generate(2,(index) => EvbikebrandnamepageItemModel());

 }
