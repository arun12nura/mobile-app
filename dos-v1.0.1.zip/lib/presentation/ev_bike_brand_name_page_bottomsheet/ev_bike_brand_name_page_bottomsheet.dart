import '../ev_bike_brand_name_page_bottomsheet/widgets/evbikebrandnamepage_item_widget.dart';
import 'models/ev_bike_brand_name_page_model.dart';
import 'models/evbikebrandnamepage_item_model.dart';
import 'package:dos/core/app_export.dart';
import 'package:flutter/material.dart';
import 'provider/ev_bike_brand_name_page_provider.dart';

// ignore_for_file: must_be_immutable
class EvBikeBrandNamePageBottomsheet extends StatefulWidget {
  const EvBikeBrandNamePageBottomsheet({Key? key})
      : super(
          key: key,
        );

  @override
  EvBikeBrandNamePageBottomsheetState createState() =>
      EvBikeBrandNamePageBottomsheetState();
  static Widget builder(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => EvBikeBrandNamePageProvider(),
      child: EvBikeBrandNamePageBottomsheet(),
    );
  }
}

class EvBikeBrandNamePageBottomsheetState
    extends State<EvBikeBrandNamePageBottomsheet> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.all(12.h),
      decoration: AppDecoration.gradientTealEToTealE.copyWith(
        borderRadius: BorderRadiusStyle.customBorderTL32,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 7.v),
          CustomImageView(
            imagePath: ImageConstant.imgRectangle6155x335,
            height: 155.v,
            width: 335.h,
            radius: BorderRadius.vertical(
              top: Radius.circular(32.h),
            ),
          ),
          SizedBox(height: 13.v),
          _buildEvBikeBrandNamePage(context),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildEvBikeBrandNamePage(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8.h),
      child: Consumer<EvBikeBrandNamePageProvider>(
        builder: (context, provider, child) {
          return ListView.separated(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (
              context,
              index,
            ) {
              return SizedBox(
                height: 16.v,
              );
            },
            itemCount: provider
                .evBikeBrandNamePageModelObj.evbikebrandnamepageItemList.length,
            itemBuilder: (context, index) {
              EvbikebrandnamepageItemModel model = provider
                  .evBikeBrandNamePageModelObj
                  .evbikebrandnamepageItemList[index];
              return EvbikebrandnamepageItemWidget(
                model,
                changeRadioButton1: (value) {
                  provider.changeRadioButton1(index, value);
                },
                changeRadioButton2: (value) {
                  provider.changeRadioButton2(index, value);
                },
              );
            },
          );
        },
      ),
    );
  }
}
