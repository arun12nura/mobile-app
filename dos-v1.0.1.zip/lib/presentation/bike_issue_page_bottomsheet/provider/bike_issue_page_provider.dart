import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/bike_issue_page_bottomsheet/models/bike_issue_page_model.dart';/// A provider class for the BikeIssuePageBottomsheet.
///
/// This provider manages the state of the BikeIssuePageBottomsheet, including the
/// current bikeIssuePageModelObj

// ignore_for_file: must_be_immutable
class BikeIssuePageProvider extends ChangeNotifier {TextEditingController labelThreeController = TextEditingController();

BikeIssuePageModel bikeIssuePageModelObj = BikeIssuePageModel();

String radioGroup = "";

@override void dispose() { super.dispose(); labelThreeController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
 }
