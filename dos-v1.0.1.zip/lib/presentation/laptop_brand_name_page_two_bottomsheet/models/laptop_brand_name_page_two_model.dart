import '../../../core/app_export.dart';class LaptopBrandNamePageTwoModel {List<String> radioList = ["lbl_laptop","lbl_computer"];

List<String> radioList1 = ["msg_company_warranty","lbl_no_warranty2"];

 }
