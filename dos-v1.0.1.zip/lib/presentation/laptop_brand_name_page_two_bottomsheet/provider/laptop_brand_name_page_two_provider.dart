import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_brand_name_page_two_bottomsheet/models/laptop_brand_name_page_two_model.dart';/// A provider class for the LaptopBrandNamePageTwoBottomsheet.
///
/// This provider manages the state of the LaptopBrandNamePageTwoBottomsheet, including the
/// current laptopBrandNamePageTwoModelObj

// ignore_for_file: must_be_immutable
class LaptopBrandNamePageTwoProvider extends ChangeNotifier {LaptopBrandNamePageTwoModel laptopBrandNamePageTwoModelObj = LaptopBrandNamePageTwoModel();

String radioGroup = "";

String warrantyDetails = "";

@override void dispose() { super.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
void changeRadioButton2(String value) { warrantyDetails = value; notifyListeners(); } 
 }
