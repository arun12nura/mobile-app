import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/car_page_bottomsheet/models/car_page_model.dart';/// A provider class for the CarPageBottomsheet.
///
/// This provider manages the state of the CarPageBottomsheet, including the
/// current carPageModelObj

// ignore_for_file: must_be_immutable
class CarPageProvider extends ChangeNotifier {TextEditingController nameController = TextEditingController();

TextEditingController issuesController = TextEditingController();

CarPageModel carPageModelObj = CarPageModel();

String radioGroup = "";

@override void dispose() { super.dispose(); nameController.dispose(); issuesController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
 }
