import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_car_vendor_details_screen/models/ev_car_vendor_details_model.dart';/// A provider class for the EvCarVendorDetailsScreen.
///
/// This provider manages the state of the EvCarVendorDetailsScreen, including the
/// current evCarVendorDetailsModelObj

// ignore_for_file: must_be_immutable
class EvCarVendorDetailsProvider extends ChangeNotifier {EvCarVendorDetailsModel evCarVendorDetailsModelObj = EvCarVendorDetailsModel();

@override void dispose() { super.dispose(); } 
 }
