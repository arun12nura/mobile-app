import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/dlete_acc_page_dialog/models/dlete_acc_page_model.dart';/// A provider class for the DleteAccPageDialog.
///
/// This provider manages the state of the DleteAccPageDialog, including the
/// current dleteAccPageModelObj

// ignore_for_file: must_be_immutable
class DleteAccPageProvider extends ChangeNotifier {DleteAccPageModel dleteAccPageModelObj = DleteAccPageModel();

@override void dispose() { super.dispose(); } 
 }
