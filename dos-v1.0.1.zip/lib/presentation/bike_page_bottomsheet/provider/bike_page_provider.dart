import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/bike_page_bottomsheet/models/bike_page_model.dart';/// A provider class for the BikePageBottomsheet.
///
/// This provider manages the state of the BikePageBottomsheet, including the
/// current bikePageModelObj

// ignore_for_file: must_be_immutable
class BikePageProvider extends ChangeNotifier {TextEditingController nameController = TextEditingController();

TextEditingController issuesController = TextEditingController();

BikePageModel bikePageModelObj = BikePageModel();

String radioGroup = "";

@override void dispose() { super.dispose(); nameController.dispose(); issuesController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
 }
