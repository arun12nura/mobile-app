import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_bike_requested_page_screen/models/ev_bike_requested_page_model.dart';/// A provider class for the EvBikeRequestedPageScreen.
///
/// This provider manages the state of the EvBikeRequestedPageScreen, including the
/// current evBikeRequestedPageModelObj

// ignore_for_file: must_be_immutable
class EvBikeRequestedPageProvider extends ChangeNotifier {EvBikeRequestedPageModel evBikeRequestedPageModelObj = EvBikeRequestedPageModel();

@override void dispose() { super.dispose(); } 
 }
