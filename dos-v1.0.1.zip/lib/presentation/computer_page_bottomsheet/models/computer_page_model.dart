import '../../../core/app_export.dart';class ComputerPageModel {List<String> radioList = ["lbl_laptop","lbl_computer"];

 }
