import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/computer_page_bottomsheet/models/computer_page_model.dart';/// A provider class for the ComputerPageBottomsheet.
///
/// This provider manages the state of the ComputerPageBottomsheet, including the
/// current computerPageModelObj

// ignore_for_file: must_be_immutable
class ComputerPageProvider extends ChangeNotifier {TextEditingController nameController = TextEditingController();

TextEditingController warrantyDetailsController = TextEditingController();

TextEditingController issuesController = TextEditingController();

ComputerPageModel computerPageModelObj = ComputerPageModel();

String radioGroup = "";

@override void dispose() { super.dispose(); nameController.dispose(); warrantyDetailsController.dispose(); issuesController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
 }
