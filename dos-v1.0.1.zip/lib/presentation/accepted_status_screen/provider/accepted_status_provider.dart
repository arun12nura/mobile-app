import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/accepted_status_screen/models/accepted_status_model.dart';/// A provider class for the AcceptedStatusScreen.
///
/// This provider manages the state of the AcceptedStatusScreen, including the
/// current acceptedStatusModelObj

// ignore_for_file: must_be_immutable
class AcceptedStatusProvider extends ChangeNotifier {AcceptedStatusModel acceptedStatusModelObj = AcceptedStatusModel();

@override void dispose() { super.dispose(); } 
 }
