import '../../../core/app_export.dart';class EvBikePageModel {List<String> radioList = ["lbl_normal","lbl_ev"];

 }
