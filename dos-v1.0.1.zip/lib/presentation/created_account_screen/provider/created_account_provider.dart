import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/created_account_screen/models/created_account_model.dart';/// A provider class for the CreatedAccountScreen.
///
/// This provider manages the state of the CreatedAccountScreen, including the
/// current createdAccountModelObj

// ignore_for_file: must_be_immutable
class CreatedAccountProvider extends ChangeNotifier {CreatedAccountModel createdAccountModelObj = CreatedAccountModel();

@override void dispose() { super.dispose(); } 
 }
