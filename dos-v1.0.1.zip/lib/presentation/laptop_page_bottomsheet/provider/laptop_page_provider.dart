import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_page_bottomsheet/models/laptop_page_model.dart';/// A provider class for the LaptopPageBottomsheet.
///
/// This provider manages the state of the LaptopPageBottomsheet, including the
/// current laptopPageModelObj

// ignore_for_file: must_be_immutable
class LaptopPageProvider extends ChangeNotifier {TextEditingController warrantyDetailsController = TextEditingController();

TextEditingController issuesController = TextEditingController();

LaptopPageModel laptopPageModelObj = LaptopPageModel();

String radioGroup = "";

String radioGroup1 = "";

@override void dispose() { super.dispose(); warrantyDetailsController.dispose(); issuesController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
void changeRadioButton2(String value) { radioGroup1 = value; notifyListeners(); } 
 }
