import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_requested_page_screen/models/laptop_requested_page_model.dart';/// A provider class for the LaptopRequestedPageScreen.
///
/// This provider manages the state of the LaptopRequestedPageScreen, including the
/// current laptopRequestedPageModelObj

// ignore_for_file: must_be_immutable
class LaptopRequestedPageProvider extends ChangeNotifier {LaptopRequestedPageModel laptopRequestedPageModelObj = LaptopRequestedPageModel();

@override void dispose() { super.dispose(); } 
 }
