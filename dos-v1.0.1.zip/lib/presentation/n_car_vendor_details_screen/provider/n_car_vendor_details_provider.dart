import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/n_car_vendor_details_screen/models/n_car_vendor_details_model.dart';/// A provider class for the NCarVendorDetailsScreen.
///
/// This provider manages the state of the NCarVendorDetailsScreen, including the
/// current nCarVendorDetailsModelObj

// ignore_for_file: must_be_immutable
class NCarVendorDetailsProvider extends ChangeNotifier {NCarVendorDetailsModel nCarVendorDetailsModelObj = NCarVendorDetailsModel();

@override void dispose() { super.dispose(); } 
 }
