import '../../../core/app_export.dart';class LaptopBrandNamePageModel {List<String> radioList = ["lbl_laptop","lbl_computer"];

List<String> radioList1 = ["lbl_hp","lbl_asus"];

 }
