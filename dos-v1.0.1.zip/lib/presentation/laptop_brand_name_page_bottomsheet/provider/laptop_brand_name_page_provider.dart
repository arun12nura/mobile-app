import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_brand_name_page_bottomsheet/models/laptop_brand_name_page_model.dart';/// A provider class for the LaptopBrandNamePageBottomsheet.
///
/// This provider manages the state of the LaptopBrandNamePageBottomsheet, including the
/// current laptopBrandNamePageModelObj

// ignore_for_file: must_be_immutable
class LaptopBrandNamePageProvider extends ChangeNotifier {LaptopBrandNamePageModel laptopBrandNamePageModelObj = LaptopBrandNamePageModel();

String radioGroup = "";

String brandName = "";

@override void dispose() { super.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
void changeRadioButton2(String value) { brandName = value; notifyListeners(); } 
 }
