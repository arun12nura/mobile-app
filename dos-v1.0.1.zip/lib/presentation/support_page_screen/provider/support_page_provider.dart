import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/support_page_screen/models/support_page_model.dart';/// A provider class for the SupportPageScreen.
///
/// This provider manages the state of the SupportPageScreen, including the
/// current supportPageModelObj

// ignore_for_file: must_be_immutable
class SupportPageProvider extends ChangeNotifier {TextEditingController nameEditTextController = TextEditingController();

TextEditingController emailEditTextController = TextEditingController();

TextEditingController problemValueEditTextController = TextEditingController();

SupportPageModel supportPageModelObj = SupportPageModel();

@override void dispose() { super.dispose(); nameEditTextController.dispose(); emailEditTextController.dispose(); problemValueEditTextController.dispose(); } 
 }
