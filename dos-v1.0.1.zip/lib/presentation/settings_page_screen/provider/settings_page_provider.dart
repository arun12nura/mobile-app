import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/settings_page_screen/models/settings_page_model.dart';/// A provider class for the SettingsPageScreen.
///
/// This provider manages the state of the SettingsPageScreen, including the
/// current settingsPageModelObj

// ignore_for_file: must_be_immutable
class SettingsPageProvider extends ChangeNotifier {SettingsPageModel settingsPageModelObj = SettingsPageModel();

@override void dispose() { super.dispose(); } 
 }
