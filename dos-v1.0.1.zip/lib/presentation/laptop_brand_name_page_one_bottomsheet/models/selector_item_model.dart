import '../../../core/app_export.dart';/// This class is used in the [selector_item_widget] screen.
class SelectorItemModel {SelectorItemModel({this.radioGroup, this.radioGroup1, this.id, }) { radioGroup = radioGroup  ?? "";radioGroup1 = radioGroup1  ?? "";id = id  ?? ""; }

String? radioGroup;

String? radioGroup1;

String? id;

 }
