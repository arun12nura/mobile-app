import 'selector_item_model.dart';import '../../../core/app_export.dart';class LaptopBrandNamePageOneModel {List<SelectorItemModel> selectorItemList = List.generate(2,(index) => SelectorItemModel());

 }
