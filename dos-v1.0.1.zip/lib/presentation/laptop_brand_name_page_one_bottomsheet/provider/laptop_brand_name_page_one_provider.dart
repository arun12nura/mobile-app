import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_brand_name_page_one_bottomsheet/models/laptop_brand_name_page_one_model.dart';import '../models/selector_item_model.dart';/// A provider class for the LaptopBrandNamePageOneBottomsheet.
///
/// This provider manages the state of the LaptopBrandNamePageOneBottomsheet, including the
/// current laptopBrandNamePageOneModelObj

// ignore_for_file: must_be_immutable
class LaptopBrandNamePageOneProvider extends ChangeNotifier {LaptopBrandNamePageOneModel laptopBrandNamePageOneModelObj = LaptopBrandNamePageOneModel();

@override void dispose() { super.dispose(); } 
void changeRadioButton1(int index, String value, ) { laptopBrandNamePageOneModelObj.selectorItemList[index].radioGroup = value;notifyListeners(); } 
void changeRadioButton2(int index, String value, ) { laptopBrandNamePageOneModelObj.selectorItemList[index].radioGroup1 = value;notifyListeners(); } 
 }
