import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/n_car_requested_page_screen/models/n_car_requested_page_model.dart';/// A provider class for the NCarRequestedPageScreen.
///
/// This provider manages the state of the NCarRequestedPageScreen, including the
/// current nCarRequestedPageModelObj

// ignore_for_file: must_be_immutable
class NCarRequestedPageProvider extends ChangeNotifier {NCarRequestedPageModel nCarRequestedPageModelObj = NCarRequestedPageModel();

@override void dispose() { super.dispose(); } 
 }
