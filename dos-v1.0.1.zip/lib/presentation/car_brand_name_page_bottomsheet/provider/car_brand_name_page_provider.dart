import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/car_brand_name_page_bottomsheet/models/car_brand_name_page_model.dart';/// A provider class for the CarBrandNamePageBottomsheet.
///
/// This provider manages the state of the CarBrandNamePageBottomsheet, including the
/// current carBrandNamePageModelObj

// ignore_for_file: must_be_immutable
class CarBrandNamePageProvider extends ChangeNotifier {CarBrandNamePageModel carBrandNamePageModelObj = CarBrandNamePageModel();

String radioGroup = "";

String radioGroup1 = "";

@override void dispose() { super.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
void changeRadioButton2(String value) { radioGroup1 = value; notifyListeners(); } 
 }
