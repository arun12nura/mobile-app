import '../../../core/app_export.dart';class CarBrandNamePageModel {List<String> radioList = ["lbl_normal","lbl_ev"];

List<String> radioList1 = ["lbl_nexa","lbl_maruti_suzuki","lbl_tata"];

 }
