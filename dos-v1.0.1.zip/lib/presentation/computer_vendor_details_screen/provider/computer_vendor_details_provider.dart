import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/computer_vendor_details_screen/models/computer_vendor_details_model.dart';/// A provider class for the ComputerVendorDetailsScreen.
///
/// This provider manages the state of the ComputerVendorDetailsScreen, including the
/// current computerVendorDetailsModelObj

// ignore_for_file: must_be_immutable
class ComputerVendorDetailsProvider extends ChangeNotifier {ComputerVendorDetailsModel computerVendorDetailsModelObj = ComputerVendorDetailsModel();

@override void dispose() { super.dispose(); } 
 }
