import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/rejected_status_screen/models/rejected_status_model.dart';/// A provider class for the RejectedStatusScreen.
///
/// This provider manages the state of the RejectedStatusScreen, including the
/// current rejectedStatusModelObj

// ignore_for_file: must_be_immutable
class RejectedStatusProvider extends ChangeNotifier {RejectedStatusModel rejectedStatusModelObj = RejectedStatusModel();

@override void dispose() { super.dispose(); } 
 }
