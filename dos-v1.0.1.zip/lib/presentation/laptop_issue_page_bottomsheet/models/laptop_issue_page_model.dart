import '../../../core/app_export.dart';class LaptopIssuePageModel {List<String> radioList = ["lbl_laptop","lbl_computer"];

 }
