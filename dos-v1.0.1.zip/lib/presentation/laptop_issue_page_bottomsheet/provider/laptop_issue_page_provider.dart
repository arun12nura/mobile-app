import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_issue_page_bottomsheet/models/laptop_issue_page_model.dart';/// A provider class for the LaptopIssuePageBottomsheet.
///
/// This provider manages the state of the LaptopIssuePageBottomsheet, including the
/// current laptopIssuePageModelObj

// ignore_for_file: must_be_immutable
class LaptopIssuePageProvider extends ChangeNotifier {LaptopIssuePageModel laptopIssuePageModelObj = LaptopIssuePageModel();

String radioGroup = "";

String radioGroup1 = "";

@override void dispose() { super.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
void changeRadioButton2(String value) { radioGroup1 = value; notifyListeners(); } 
 }
