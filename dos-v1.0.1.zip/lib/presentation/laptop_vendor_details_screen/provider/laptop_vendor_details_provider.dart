import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_vendor_details_screen/models/laptop_vendor_details_model.dart';/// A provider class for the LaptopVendorDetailsScreen.
///
/// This provider manages the state of the LaptopVendorDetailsScreen, including the
/// current laptopVendorDetailsModelObj

// ignore_for_file: must_be_immutable
class LaptopVendorDetailsProvider extends ChangeNotifier {LaptopVendorDetailsModel laptopVendorDetailsModelObj = LaptopVendorDetailsModel();

@override void dispose() { super.dispose(); } 
 }
