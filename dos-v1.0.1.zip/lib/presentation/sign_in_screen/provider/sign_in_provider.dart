import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/sign_in_screen/models/sign_in_model.dart';/// A provider class for the SignInScreen.
///
/// This provider manages the state of the SignInScreen, including the
/// current signInModelObj

// ignore_for_file: must_be_immutable
class SignInProvider extends ChangeNotifier {TextEditingController userNameController = TextEditingController();

TextEditingController passwordController = TextEditingController();

SignInModel signInModelObj = SignInModel();

@override void dispose() { super.dispose(); userNameController.dispose(); passwordController.dispose(); } 
 }
