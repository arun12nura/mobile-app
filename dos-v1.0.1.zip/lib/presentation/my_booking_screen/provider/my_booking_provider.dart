import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/my_booking_screen/models/my_booking_model.dart';import '../models/userprofilelist_item_model.dart';/// A provider class for the MyBookingScreen.
///
/// This provider manages the state of the MyBookingScreen, including the
/// current myBookingModelObj

// ignore_for_file: must_be_immutable
class MyBookingProvider extends ChangeNotifier {MyBookingModel myBookingModelObj = MyBookingModel();

@override void dispose() { super.dispose(); } 
 }
