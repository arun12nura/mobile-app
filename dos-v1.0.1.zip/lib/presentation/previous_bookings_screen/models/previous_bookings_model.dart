import '../../../core/app_export.dart';import 'userprofile_item_model.dart';class PreviousBookingsModel {List<UserprofileItemModel> userprofileItemList = [UserprofileItemModel(userImage:ImageConstant.imgRectangle3391x110,settingsImage:ImageConstant.imgSettings,text1: "z",text2: "Swift ",text3: "Dzire LXi 2019",text4: "Speedometer "),UserprofileItemModel(userImage:ImageConstant.imgRectangle331,settingsImage:ImageConstant.imgSettingsBlack90001,text1: "z",text2: "Royal enfield",text3: "Classic 350",text4: "Starting Trouble ")];

 }
