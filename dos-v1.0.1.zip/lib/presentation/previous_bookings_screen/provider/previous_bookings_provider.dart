import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/previous_bookings_screen/models/previous_bookings_model.dart';import '../models/userprofile_item_model.dart';/// A provider class for the PreviousBookingsScreen.
///
/// This provider manages the state of the PreviousBookingsScreen, including the
/// current previousBookingsModelObj

// ignore_for_file: must_be_immutable
class PreviousBookingsProvider extends ChangeNotifier {PreviousBookingsModel previousBookingsModelObj = PreviousBookingsModel();

@override void dispose() { super.dispose(); } 
 }
