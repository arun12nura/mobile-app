import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_car_requested_page_screen/models/ev_car_requested_page_model.dart';/// A provider class for the EvCarRequestedPageScreen.
///
/// This provider manages the state of the EvCarRequestedPageScreen, including the
/// current evCarRequestedPageModelObj

// ignore_for_file: must_be_immutable
class EvCarRequestedPageProvider extends ChangeNotifier {EvCarRequestedPageModel evCarRequestedPageModelObj = EvCarRequestedPageModel();

@override void dispose() { super.dispose(); } 
 }
