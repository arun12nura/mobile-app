import '../../../core/app_export.dart';class EvCarPageModel {List<String> radioList = ["lbl_normal","lbl_ev"];

 }
