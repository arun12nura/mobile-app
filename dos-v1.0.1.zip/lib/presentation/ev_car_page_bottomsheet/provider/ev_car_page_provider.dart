import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_car_page_bottomsheet/models/ev_car_page_model.dart';/// A provider class for the EvCarPageBottomsheet.
///
/// This provider manages the state of the EvCarPageBottomsheet, including the
/// current evCarPageModelObj

// ignore_for_file: must_be_immutable
class EvCarPageProvider extends ChangeNotifier {TextEditingController nameController = TextEditingController();

TextEditingController issuesController = TextEditingController();

EvCarPageModel evCarPageModelObj = EvCarPageModel();

String radioGroup = "";

@override void dispose() { super.dispose(); nameController.dispose(); issuesController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
 }
