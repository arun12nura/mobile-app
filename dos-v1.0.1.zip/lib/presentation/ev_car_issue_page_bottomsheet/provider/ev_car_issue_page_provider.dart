import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_car_issue_page_bottomsheet/models/ev_car_issue_page_model.dart';/// A provider class for the EvCarIssuePageBottomsheet.
///
/// This provider manages the state of the EvCarIssuePageBottomsheet, including the
/// current evCarIssuePageModelObj

// ignore_for_file: must_be_immutable
class EvCarIssuePageProvider extends ChangeNotifier {TextEditingController labelThreeController = TextEditingController();

EvCarIssuePageModel evCarIssuePageModelObj = EvCarIssuePageModel();

String radioGroup = "";

@override void dispose() { super.dispose(); labelThreeController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
 }
