import '../../../core/app_export.dart';class CarIssuePageModel {List<String> radioList = ["lbl_normal","lbl_ev"];

 }
