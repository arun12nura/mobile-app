import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/car_issue_page_bottomsheet/models/car_issue_page_model.dart';/// A provider class for the CarIssuePageBottomsheet.
///
/// This provider manages the state of the CarIssuePageBottomsheet, including the
/// current carIssuePageModelObj

// ignore_for_file: must_be_immutable
class CarIssuePageProvider extends ChangeNotifier {CarIssuePageModel carIssuePageModelObj = CarIssuePageModel();

String radioGroup = "";

String radioGroup1 = "";

@override void dispose() { super.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
void changeRadioButton2(String value) { radioGroup1 = value; notifyListeners(); } 
 }
