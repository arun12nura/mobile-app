import 'package:flutter/material.dart';
import 'package:dos/core/app_export.dart';
import 'package:dos/presentation/referal_page_screen/models/referal_page_model.dart';

/// A provider class for the ReferalPageScreen.
///
/// This provider manages the state of the ReferalPageScreen, including the
/// current referalPageModelObj
class ReferalPageProvider extends ChangeNotifier {
  TextEditingController searchController = TextEditingController();

  ReferalPageModel referalPageModelObj = ReferalPageModel();

  @override
  void dispose() {
    super.dispose();
    searchController.dispose();
  }
}
