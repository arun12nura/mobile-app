import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_brand_name_page_three_bottomsheet/models/laptop_brand_name_page_three_model.dart';/// A provider class for the LaptopBrandNamePageThreeBottomsheet.
///
/// This provider manages the state of the LaptopBrandNamePageThreeBottomsheet, including the
/// current laptopBrandNamePageThreeModelObj

// ignore_for_file: must_be_immutable
class LaptopBrandNamePageThreeProvider extends ChangeNotifier {LaptopBrandNamePageThreeModel laptopBrandNamePageThreeModelObj = LaptopBrandNamePageThreeModel();

String radioGroup = "";

String warrantyDetails = "";

@override void dispose() { super.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
void changeRadioButton2(String value) { warrantyDetails = value; notifyListeners(); } 
 }
