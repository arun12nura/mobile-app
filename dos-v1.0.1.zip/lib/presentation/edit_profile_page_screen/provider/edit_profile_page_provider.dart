import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/edit_profile_page_screen/models/edit_profile_page_model.dart';/// A provider class for the EditProfilePageScreen.
///
/// This provider manages the state of the EditProfilePageScreen, including the
/// current editProfilePageModelObj

// ignore_for_file: must_be_immutable
class EditProfilePageProvider extends ChangeNotifier {TextEditingController nameEditTextController = TextEditingController();

TextEditingController phoneEditTextController = TextEditingController();

TextEditingController emailEditTextController = TextEditingController();

EditProfilePageModel editProfilePageModelObj = EditProfilePageModel();

@override void dispose() { super.dispose(); nameEditTextController.dispose(); phoneEditTextController.dispose(); emailEditTextController.dispose(); } 
 }
