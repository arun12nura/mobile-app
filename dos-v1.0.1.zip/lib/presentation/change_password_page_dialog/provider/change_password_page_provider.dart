import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/change_password_page_dialog/models/change_password_page_model.dart';/// A provider class for the ChangePasswordPageDialog.
///
/// This provider manages the state of the ChangePasswordPageDialog, including the
/// current changePasswordPageModelObj

// ignore_for_file: must_be_immutable
class ChangePasswordPageProvider extends ChangeNotifier {TextEditingController passwordFieldController = TextEditingController();

TextEditingController newPasswordFieldController = TextEditingController();

TextEditingController retypeNewPasswordFieldController = TextEditingController();

ChangePasswordPageModel changePasswordPageModelObj = ChangePasswordPageModel();

@override void dispose() { super.dispose(); passwordFieldController.dispose(); newPasswordFieldController.dispose(); retypeNewPasswordFieldController.dispose(); } 
 }
