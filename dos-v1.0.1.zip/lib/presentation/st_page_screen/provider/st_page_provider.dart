import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/st_page_screen/models/st_page_model.dart';/// A provider class for the StPageScreen.
///
/// This provider manages the state of the StPageScreen, including the
/// current stPageModelObj

// ignore_for_file: must_be_immutable
class StPageProvider extends ChangeNotifier {StPageModel stPageModelObj = StPageModel();

@override void dispose() { super.dispose(); } 
 }
