import '../../../core/app_export.dart';class EvBikeIssuePageModel {List<String> radioList = ["lbl_normal","lbl_ev"];

 }
