import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_bike_issue_page_bottomsheet/models/ev_bike_issue_page_model.dart';/// A provider class for the EvBikeIssuePageBottomsheet.
///
/// This provider manages the state of the EvBikeIssuePageBottomsheet, including the
/// current evBikeIssuePageModelObj

// ignore_for_file: must_be_immutable
class EvBikeIssuePageProvider extends ChangeNotifier {TextEditingController labelThreeController = TextEditingController();

EvBikeIssuePageModel evBikeIssuePageModelObj = EvBikeIssuePageModel();

String radioGroup = "";

@override void dispose() { super.dispose(); labelThreeController.dispose(); } 
void changeRadioButton1(String value) { radioGroup = value; notifyListeners(); } 
 }
