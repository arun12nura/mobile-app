import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/n_bike_vendor_details_screen/models/n_bike_vendor_details_model.dart';/// A provider class for the NBikeVendorDetailsScreen.
///
/// This provider manages the state of the NBikeVendorDetailsScreen, including the
/// current nBikeVendorDetailsModelObj

// ignore_for_file: must_be_immutable
class NBikeVendorDetailsProvider extends ChangeNotifier {NBikeVendorDetailsModel nBikeVendorDetailsModelObj = NBikeVendorDetailsModel();

@override void dispose() { super.dispose(); } 
 }
