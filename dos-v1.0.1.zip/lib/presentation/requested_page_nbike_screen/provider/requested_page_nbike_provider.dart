import 'package:flutter/material.dart';import 'package:dos/core/app_export.dart';import 'package:dos/presentation/requested_page_nbike_screen/models/requested_page_nbike_model.dart';/// A provider class for the RequestedPageNbikeScreen.
///
/// This provider manages the state of the RequestedPageNbikeScreen, including the
/// current requestedPageNbikeModelObj

// ignore_for_file: must_be_immutable
class RequestedPageNbikeProvider extends ChangeNotifier {RequestedPageNbikeModel requestedPageNbikeModelObj = RequestedPageNbikeModel();

@override void dispose() { super.dispose(); } 
 }
