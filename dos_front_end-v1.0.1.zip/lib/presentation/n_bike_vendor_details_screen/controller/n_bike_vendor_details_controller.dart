import 'package:dos_front_end/core/app_export.dart';import 'package:dos_front_end/presentation/n_bike_vendor_details_screen/models/n_bike_vendor_details_model.dart';/// A controller class for the NBikeVendorDetailsScreen.
///
/// This class manages the state of the NBikeVendorDetailsScreen, including the
/// current nBikeVendorDetailsModelObj
class NBikeVendorDetailsController extends GetxController {Rx<NBikeVendorDetailsModel> nBikeVendorDetailsModelObj = NBikeVendorDetailsModel().obs;

 }
