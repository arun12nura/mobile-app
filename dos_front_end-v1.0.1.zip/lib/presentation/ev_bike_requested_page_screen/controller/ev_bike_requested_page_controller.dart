import 'package:dos_front_end/core/app_export.dart';import 'package:dos_front_end/presentation/ev_bike_requested_page_screen/models/ev_bike_requested_page_model.dart';/// A controller class for the EvBikeRequestedPageScreen.
///
/// This class manages the state of the EvBikeRequestedPageScreen, including the
/// current evBikeRequestedPageModelObj
class EvBikeRequestedPageController extends GetxController {Rx<EvBikeRequestedPageModel> evBikeRequestedPageModelObj = EvBikeRequestedPageModel().obs;

 }
