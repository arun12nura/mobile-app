import 'package:dos_front_end/core/app_export.dart';import 'package:dos_front_end/presentation/n_car_requested_page_screen/models/n_car_requested_page_model.dart';/// A controller class for the NCarRequestedPageScreen.
///
/// This class manages the state of the NCarRequestedPageScreen, including the
/// current nCarRequestedPageModelObj
class NCarRequestedPageController extends GetxController {Rx<NCarRequestedPageModel> nCarRequestedPageModelObj = NCarRequestedPageModel().obs;

 }
