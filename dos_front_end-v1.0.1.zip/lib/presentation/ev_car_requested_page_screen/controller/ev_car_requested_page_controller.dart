import 'package:dos_front_end/core/app_export.dart';import 'package:dos_front_end/presentation/ev_car_requested_page_screen/models/ev_car_requested_page_model.dart';/// A controller class for the EvCarRequestedPageScreen.
///
/// This class manages the state of the EvCarRequestedPageScreen, including the
/// current evCarRequestedPageModelObj
class EvCarRequestedPageController extends GetxController {Rx<EvCarRequestedPageModel> evCarRequestedPageModelObj = EvCarRequestedPageModel().obs;

 }
