import 'package:dos_front_end/core/app_export.dart';import 'package:dos_front_end/presentation/accepted_status_screen/models/accepted_status_model.dart';/// A controller class for the AcceptedStatusScreen.
///
/// This class manages the state of the AcceptedStatusScreen, including the
/// current acceptedStatusModelObj
class AcceptedStatusController extends GetxController {Rx<AcceptedStatusModel> acceptedStatusModelObj = AcceptedStatusModel().obs;

 }
