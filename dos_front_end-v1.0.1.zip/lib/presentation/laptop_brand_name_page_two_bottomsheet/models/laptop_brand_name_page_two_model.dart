import '../../../core/app_export.dart';/// This class defines the variables used in the [laptop_brand_name_page_two_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class LaptopBrandNamePageTwoModel {Rx<List<String>> radioList = Rx(["lbl_laptop","lbl_computer"]);

Rx<List<String>> radioList1 = Rx(["msg_company_warranty","lbl_no_warranty2"]);

 }
