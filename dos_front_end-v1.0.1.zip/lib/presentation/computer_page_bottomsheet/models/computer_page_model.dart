import '../../../core/app_export.dart';/// This class defines the variables used in the [computer_page_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class ComputerPageModel {Rx<List<String>> radioList = Rx(["lbl_laptop","lbl_computer"]);

 }
