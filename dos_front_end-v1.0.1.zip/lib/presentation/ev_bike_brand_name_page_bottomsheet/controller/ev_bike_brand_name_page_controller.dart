import 'package:dos_front_end/core/app_export.dart';import 'package:dos_front_end/presentation/ev_bike_brand_name_page_bottomsheet/models/ev_bike_brand_name_page_model.dart';/// A controller class for the EvBikeBrandNamePageBottomsheet.
///
/// This class manages the state of the EvBikeBrandNamePageBottomsheet, including the
/// current evBikeBrandNamePageModelObj
class EvBikeBrandNamePageController extends GetxController {Rx<EvBikeBrandNamePageModel> evBikeBrandNamePageModelObj = EvBikeBrandNamePageModel().obs;

 }
