import 'package:dos_front_end/core/app_export.dart';import 'package:dos_front_end/presentation/ev_car_brand_name_page_bottomsheet/models/ev_car_brand_name_page_model.dart';/// A controller class for the EvCarBrandNamePageBottomsheet.
///
/// This class manages the state of the EvCarBrandNamePageBottomsheet, including the
/// current evCarBrandNamePageModelObj
class EvCarBrandNamePageController extends GetxController {Rx<EvCarBrandNamePageModel> evCarBrandNamePageModelObj = EvCarBrandNamePageModel().obs;

 }
