import 'package:dos_front_end/core/app_export.dart';

class ApiClient extends GetConnect {}
