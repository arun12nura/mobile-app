import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_car_vendor_details_screen/models/ev_car_vendor_details_model.dart';/// A controller class for the EvCarVendorDetailsScreen.
///
/// This class manages the state of the EvCarVendorDetailsScreen, including the
/// current evCarVendorDetailsModelObj
class EvCarVendorDetailsController extends GetxController {Rx<EvCarVendorDetailsModel> evCarVendorDetailsModelObj = EvCarVendorDetailsModel().obs;

 }
