import 'package:dos/core/app_export.dart';import 'package:dos/presentation/ev_bike_vendor_detailse_page_screen/models/ev_bike_vendor_detailse_page_model.dart';/// A controller class for the EvBikeVendorDetailsePageScreen.
///
/// This class manages the state of the EvBikeVendorDetailsePageScreen, including the
/// current evBikeVendorDetailsePageModelObj
class EvBikeVendorDetailsePageController extends GetxController {Rx<EvBikeVendorDetailsePageModel> evBikeVendorDetailsePageModelObj = EvBikeVendorDetailsePageModel().obs;

 }
