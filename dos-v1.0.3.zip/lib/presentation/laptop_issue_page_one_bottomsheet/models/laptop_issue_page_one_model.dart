import '../../../core/app_export.dart';/// This class defines the variables used in the [laptop_issue_page_one_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class LaptopIssuePageOneModel {Rx<List<String>> radioList = Rx(["lbl_laptop","lbl_computer"]);

 }
