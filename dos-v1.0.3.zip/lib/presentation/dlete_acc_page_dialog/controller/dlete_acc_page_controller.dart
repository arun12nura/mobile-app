import 'package:dos/core/app_export.dart';import 'package:dos/presentation/dlete_acc_page_dialog/models/dlete_acc_page_model.dart';/// A controller class for the DleteAccPageDialog.
///
/// This class manages the state of the DleteAccPageDialog, including the
/// current dleteAccPageModelObj
class DleteAccPageController extends GetxController {Rx<DleteAccPageModel> dleteAccPageModelObj = DleteAccPageModel().obs;

 }
