import 'package:dos/core/app_export.dart';import 'package:dos/presentation/laptop_brand_name_page_one_bottomsheet/models/laptop_brand_name_page_one_model.dart';/// A controller class for the LaptopBrandNamePageOneBottomsheet.
///
/// This class manages the state of the LaptopBrandNamePageOneBottomsheet, including the
/// current laptopBrandNamePageOneModelObj
class LaptopBrandNamePageOneController extends GetxController {Rx<LaptopBrandNamePageOneModel> laptopBrandNamePageOneModelObj = LaptopBrandNamePageOneModel().obs;

 }
