import 'package:dos/core/app_export.dart';

class ApiClient extends GetConnect {}
