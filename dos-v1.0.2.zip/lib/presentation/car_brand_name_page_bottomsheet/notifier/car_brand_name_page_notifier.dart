import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/car_brand_name_page_bottomsheet/models/car_brand_name_page_model.dart';part 'car_brand_name_page_state.dart';final carBrandNamePageNotifier = StateNotifierProvider<CarBrandNamePageNotifier, CarBrandNamePageState>((ref) => CarBrandNamePageNotifier(CarBrandNamePageState(radioGroup: '', radioGroup1: '', carBrandNamePageModelObj: CarBrandNamePageModel(radioList: ["lbl_normal", "lbl_ev"], radioList1: ["lbl_nexa", "lbl_maruti_suzuki", "lbl_tata"]))));
/// A notifier that manages the state of a CarBrandNamePage according to the event that is dispatched to it.
class CarBrandNamePageNotifier extends StateNotifier<CarBrandNamePageState> {CarBrandNamePageNotifier(CarBrandNamePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
void changeRadioButton2(String value) { state = state.copyWith(radioGroup1: value); } 
 }
