import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/laptop_page_bottomsheet/models/laptop_page_model.dart';part 'laptop_page_state.dart';final laptopPageNotifier = StateNotifierProvider<LaptopPageNotifier, LaptopPageState>((ref) => LaptopPageNotifier(LaptopPageState(warrantyDetailsController: TextEditingController(), issuesController: TextEditingController(), radioGroup: '', radioGroup1: '', laptopPageModelObj: LaptopPageModel(radioList: ["lbl_laptop", "lbl_computer"]))));
/// A notifier that manages the state of a LaptopPage according to the event that is dispatched to it.
class LaptopPageNotifier extends StateNotifier<LaptopPageState> {LaptopPageNotifier(LaptopPageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
void changeRadioButton2(String value) { state = state.copyWith(radioGroup1: value); } 
 }
