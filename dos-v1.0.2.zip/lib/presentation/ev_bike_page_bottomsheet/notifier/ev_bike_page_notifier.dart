import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/ev_bike_page_bottomsheet/models/ev_bike_page_model.dart';part 'ev_bike_page_state.dart';final evBikePageNotifier = StateNotifierProvider<EvBikePageNotifier, EvBikePageState>((ref) => EvBikePageNotifier(EvBikePageState(nameController: TextEditingController(), issuesController: TextEditingController(), radioGroup: '', evBikePageModelObj: EvBikePageModel(radioList: ["lbl_normal", "lbl_ev"]))));
/// A notifier that manages the state of a EvBikePage according to the event that is dispatched to it.
class EvBikePageNotifier extends StateNotifier<EvBikePageState> {EvBikePageNotifier(EvBikePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
 }
