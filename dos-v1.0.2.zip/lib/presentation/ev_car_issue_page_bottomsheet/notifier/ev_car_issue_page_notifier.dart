import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/ev_car_issue_page_bottomsheet/models/ev_car_issue_page_model.dart';part 'ev_car_issue_page_state.dart';final evCarIssuePageNotifier = StateNotifierProvider<EvCarIssuePageNotifier, EvCarIssuePageState>((ref) => EvCarIssuePageNotifier(EvCarIssuePageState(labelThreeController: TextEditingController(), radioGroup: '', evCarIssuePageModelObj: EvCarIssuePageModel(radioList: ["lbl_normal", "lbl_ev"]))));
/// A notifier that manages the state of a EvCarIssuePage according to the event that is dispatched to it.
class EvCarIssuePageNotifier extends StateNotifier<EvCarIssuePageState> {EvCarIssuePageNotifier(EvCarIssuePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
 }
