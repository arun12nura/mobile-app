import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/support_page_screen/models/support_page_model.dart';part 'support_page_state.dart';final supportPageNotifier = StateNotifierProvider<SupportPageNotifier, SupportPageState>((ref) => SupportPageNotifier(SupportPageState(nameEditTextController: TextEditingController(), emailEditTextController: TextEditingController(), problemValueEditTextController: TextEditingController(), supportPageModelObj: SupportPageModel())));
/// A notifier that manages the state of a SupportPage according to the event that is dispatched to it.
class SupportPageNotifier extends StateNotifier<SupportPageState> {SupportPageNotifier(SupportPageState state) : super(state);

 }
