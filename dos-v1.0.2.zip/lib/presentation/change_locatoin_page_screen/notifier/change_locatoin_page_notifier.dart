import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/change_locatoin_page_screen/models/change_locatoin_page_model.dart';part 'change_locatoin_page_state.dart';final changeLocatoinPageNotifier = StateNotifierProvider<ChangeLocatoinPageNotifier, ChangeLocatoinPageState>((ref) => ChangeLocatoinPageNotifier(ChangeLocatoinPageState(searchController: TextEditingController(), changeLocatoinPageModelObj: ChangeLocatoinPageModel())));
/// A notifier that manages the state of a ChangeLocatoinPage according to the event that is dispatched to it.
class ChangeLocatoinPageNotifier extends StateNotifier<ChangeLocatoinPageState> {ChangeLocatoinPageNotifier(ChangeLocatoinPageState state) : super(state);

 }
