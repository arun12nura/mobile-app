import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/ev_bike_vendor_detailse_page_screen/models/ev_bike_vendor_detailse_page_model.dart';part 'ev_bike_vendor_detailse_page_state.dart';final evBikeVendorDetailsePageNotifier = StateNotifierProvider<EvBikeVendorDetailsePageNotifier, EvBikeVendorDetailsePageState>((ref) => EvBikeVendorDetailsePageNotifier(EvBikeVendorDetailsePageState(evBikeVendorDetailsePageModelObj: EvBikeVendorDetailsePageModel())));
/// A notifier that manages the state of a EvBikeVendorDetailsePage according to the event that is dispatched to it.
class EvBikeVendorDetailsePageNotifier extends StateNotifier<EvBikeVendorDetailsePageState> {EvBikeVendorDetailsePageNotifier(EvBikeVendorDetailsePageState state) : super(state);

 }
