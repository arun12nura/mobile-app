import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/accepted_status_screen/models/accepted_status_model.dart';part 'accepted_status_state.dart';final acceptedStatusNotifier = StateNotifierProvider<AcceptedStatusNotifier, AcceptedStatusState>((ref) => AcceptedStatusNotifier(AcceptedStatusState(acceptedStatusModelObj: AcceptedStatusModel())));
/// A notifier that manages the state of a AcceptedStatus according to the event that is dispatched to it.
class AcceptedStatusNotifier extends StateNotifier<AcceptedStatusState> {AcceptedStatusNotifier(AcceptedStatusState state) : super(state);

 }
