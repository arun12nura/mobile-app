import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/bike_brand_name_page_bottomsheet/models/bike_brand_name_page_model.dart';part 'bike_brand_name_page_state.dart';final bikeBrandNamePageNotifier = StateNotifierProvider<BikeBrandNamePageNotifier, BikeBrandNamePageState>((ref) => BikeBrandNamePageNotifier(BikeBrandNamePageState(radioGroup: '', brandName: '', bikeBrandNamePageModelObj: BikeBrandNamePageModel(radioList: ["lbl_yamaha", "lbl_honda"]))));
/// A notifier that manages the state of a BikeBrandNamePage according to the event that is dispatched to it.
class BikeBrandNamePageNotifier extends StateNotifier<BikeBrandNamePageState> {BikeBrandNamePageNotifier(BikeBrandNamePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
void changeRadioButton2(String value) { state = state.copyWith(brandName: value); } 
 }
