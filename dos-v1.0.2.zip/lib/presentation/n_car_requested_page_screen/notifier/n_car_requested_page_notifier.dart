import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/n_car_requested_page_screen/models/n_car_requested_page_model.dart';part 'n_car_requested_page_state.dart';final nCarRequestedPageNotifier = StateNotifierProvider<NCarRequestedPageNotifier, NCarRequestedPageState>((ref) => NCarRequestedPageNotifier(NCarRequestedPageState(nCarRequestedPageModelObj: NCarRequestedPageModel())));
/// A notifier that manages the state of a NCarRequestedPage according to the event that is dispatched to it.
class NCarRequestedPageNotifier extends StateNotifier<NCarRequestedPageState> {NCarRequestedPageNotifier(NCarRequestedPageState state) : super(state);

 }
