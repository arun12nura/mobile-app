import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/selector_item_model.dart';
import 'package:dos/presentation/laptop_brand_name_page_one_bottomsheet/models/laptop_brand_name_page_one_model.dart';
part 'laptop_brand_name_page_one_state.dart';

final laptopBrandNamePageOneNotifier = StateNotifierProvider<
    LaptopBrandNamePageOneNotifier, LaptopBrandNamePageOneState>(
  (ref) => LaptopBrandNamePageOneNotifier(LaptopBrandNamePageOneState(
    laptopBrandNamePageOneModelObj: LaptopBrandNamePageOneModel(
        selectorItemList: List.generate(2, (index) => SelectorItemModel())),
  )),
);

/// A notifier that manages the state of a LaptopBrandNamePageOne according to the event that is dispatched to it.
class LaptopBrandNamePageOneNotifier
    extends StateNotifier<LaptopBrandNamePageOneState> {
  LaptopBrandNamePageOneNotifier(LaptopBrandNamePageOneState state)
      : super(state) {}

  void changeRadioButton1(
    int index,
    String value,
  ) {
    List<SelectorItemModel> newList = List<SelectorItemModel>.from(
        state.laptopBrandNamePageOneModelObj!.selectorItemList);
    newList[index] = newList[index].copyWith(radioGroup: value);
    state = state.copyWith(
        laptopBrandNamePageOneModelObj: state.laptopBrandNamePageOneModelObj
            ?.copyWith(selectorItemList: newList));
  }

  void changeRadioButton2(
    int index,
    String value,
  ) {
    List<SelectorItemModel> newList = List<SelectorItemModel>.from(
        state.laptopBrandNamePageOneModelObj!.selectorItemList);
    newList[index] = newList[index].copyWith(radioGroup1: value);
    state = state.copyWith(
        laptopBrandNamePageOneModelObj: state.laptopBrandNamePageOneModelObj
            ?.copyWith(selectorItemList: newList));
  }
}
