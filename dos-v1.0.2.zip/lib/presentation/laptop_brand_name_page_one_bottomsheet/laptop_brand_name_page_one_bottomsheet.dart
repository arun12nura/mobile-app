import '../laptop_brand_name_page_one_bottomsheet/widgets/selector_item_widget.dart';
import 'models/selector_item_model.dart';
import 'notifier/laptop_brand_name_page_one_notifier.dart';
import 'package:dos/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class LaptopBrandNamePageOneBottomsheet extends ConsumerStatefulWidget {
  const LaptopBrandNamePageOneBottomsheet({Key? key})
      : super(
          key: key,
        );

  @override
  LaptopBrandNamePageOneBottomsheetState createState() =>
      LaptopBrandNamePageOneBottomsheetState();
}

class LaptopBrandNamePageOneBottomsheetState
    extends ConsumerState<LaptopBrandNamePageOneBottomsheet> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.all(12.h),
      decoration: AppDecoration.gradientTealEToTealE.copyWith(
        borderRadius: BorderRadiusStyle.customBorderTL32,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage155x335,
            height: 155.v,
            width: 335.h,
            radius: BorderRadius.vertical(
              top: Radius.circular(32.h),
            ),
          ),
          SizedBox(height: 20.v),
          _buildSelector(context),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSelector(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8.h),
      child: Consumer(
        builder: (context, ref, _) {
          return ListView.separated(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (
              context,
              index,
            ) {
              return SizedBox(
                height: 16.v,
              );
            },
            itemCount: ref
                    .watch(laptopBrandNamePageOneNotifier)
                    .laptopBrandNamePageOneModelObj
                    ?.selectorItemList
                    .length ??
                0,
            itemBuilder: (context, index) {
              SelectorItemModel model = ref
                      .watch(laptopBrandNamePageOneNotifier)
                      .laptopBrandNamePageOneModelObj
                      ?.selectorItemList[index] ??
                  SelectorItemModel();
              return SelectorItemWidget(
                model,
                changeRadioButton1: (value) {
                  ref
                      .read(laptopBrandNamePageOneNotifier.notifier)
                      .changeRadioButton1(index, value);
                },
                changeRadioButton2: (value) {
                  ref
                      .read(laptopBrandNamePageOneNotifier.notifier)
                      .changeRadioButton2(index, value);
                },
              );
            },
          );
        },
      ),
    );
  }
}
