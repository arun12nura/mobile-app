import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/settings_page_screen/models/settings_page_model.dart';part 'settings_page_state.dart';final settingsPageNotifier = StateNotifierProvider<SettingsPageNotifier, SettingsPageState>((ref) => SettingsPageNotifier(SettingsPageState(settingsPageModelObj: SettingsPageModel())));
/// A notifier that manages the state of a SettingsPage according to the event that is dispatched to it.
class SettingsPageNotifier extends StateNotifier<SettingsPageState> {SettingsPageNotifier(SettingsPageState state) : super(state);

 }
