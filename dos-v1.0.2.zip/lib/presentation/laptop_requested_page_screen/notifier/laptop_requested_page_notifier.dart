import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/laptop_requested_page_screen/models/laptop_requested_page_model.dart';part 'laptop_requested_page_state.dart';final laptopRequestedPageNotifier = StateNotifierProvider<LaptopRequestedPageNotifier, LaptopRequestedPageState>((ref) => LaptopRequestedPageNotifier(LaptopRequestedPageState(laptopRequestedPageModelObj: LaptopRequestedPageModel())));
/// A notifier that manages the state of a LaptopRequestedPage according to the event that is dispatched to it.
class LaptopRequestedPageNotifier extends StateNotifier<LaptopRequestedPageState> {LaptopRequestedPageNotifier(LaptopRequestedPageState state) : super(state);

 }
