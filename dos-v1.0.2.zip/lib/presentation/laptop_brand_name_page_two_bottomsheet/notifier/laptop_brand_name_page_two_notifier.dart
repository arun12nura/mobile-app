import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/laptop_brand_name_page_two_bottomsheet/models/laptop_brand_name_page_two_model.dart';part 'laptop_brand_name_page_two_state.dart';final laptopBrandNamePageTwoNotifier = StateNotifierProvider<LaptopBrandNamePageTwoNotifier, LaptopBrandNamePageTwoState>((ref) => LaptopBrandNamePageTwoNotifier(LaptopBrandNamePageTwoState(radioGroup: '', warrantyDetails: '', laptopBrandNamePageTwoModelObj: LaptopBrandNamePageTwoModel(radioList: ["lbl_laptop", "lbl_computer"], radioList1: ["msg_company_warranty", "lbl_no_warranty2"]))));
/// A notifier that manages the state of a LaptopBrandNamePageTwo according to the event that is dispatched to it.
class LaptopBrandNamePageTwoNotifier extends StateNotifier<LaptopBrandNamePageTwoState> {LaptopBrandNamePageTwoNotifier(LaptopBrandNamePageTwoState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
void changeRadioButton2(String value) { state = state.copyWith(warrantyDetails: value); } 
 }
