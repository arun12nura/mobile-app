import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/rejected_status_screen/models/rejected_status_model.dart';part 'rejected_status_state.dart';final rejectedStatusNotifier = StateNotifierProvider<RejectedStatusNotifier, RejectedStatusState>((ref) => RejectedStatusNotifier(RejectedStatusState(rejectedStatusModelObj: RejectedStatusModel())));
/// A notifier that manages the state of a RejectedStatus according to the event that is dispatched to it.
class RejectedStatusNotifier extends StateNotifier<RejectedStatusState> {RejectedStatusNotifier(RejectedStatusState state) : super(state);

 }
