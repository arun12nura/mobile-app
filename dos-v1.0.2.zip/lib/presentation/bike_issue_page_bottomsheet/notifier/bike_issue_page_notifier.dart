import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/bike_issue_page_bottomsheet/models/bike_issue_page_model.dart';part 'bike_issue_page_state.dart';final bikeIssuePageNotifier = StateNotifierProvider<BikeIssuePageNotifier, BikeIssuePageState>((ref) => BikeIssuePageNotifier(BikeIssuePageState(labelThreeController: TextEditingController(), radioGroup: '', bikeIssuePageModelObj: BikeIssuePageModel())));
/// A notifier that manages the state of a BikeIssuePage according to the event that is dispatched to it.
class BikeIssuePageNotifier extends StateNotifier<BikeIssuePageState> {BikeIssuePageNotifier(BikeIssuePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
 }
