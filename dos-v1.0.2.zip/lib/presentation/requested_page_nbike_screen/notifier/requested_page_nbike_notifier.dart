import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/requested_page_nbike_screen/models/requested_page_nbike_model.dart';part 'requested_page_nbike_state.dart';final requestedPageNbikeNotifier = StateNotifierProvider<RequestedPageNbikeNotifier, RequestedPageNbikeState>((ref) => RequestedPageNbikeNotifier(RequestedPageNbikeState(requestedPageNbikeModelObj: RequestedPageNbikeModel())));
/// A notifier that manages the state of a RequestedPageNbike according to the event that is dispatched to it.
class RequestedPageNbikeNotifier extends StateNotifier<RequestedPageNbikeState> {RequestedPageNbikeNotifier(RequestedPageNbikeState state) : super(state);

 }
