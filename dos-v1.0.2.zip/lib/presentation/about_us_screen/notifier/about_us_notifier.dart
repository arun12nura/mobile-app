import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/about_us_screen/models/about_us_model.dart';part 'about_us_state.dart';final aboutUsNotifier = StateNotifierProvider<AboutUsNotifier, AboutUsState>((ref) => AboutUsNotifier(AboutUsState(aboutUsModelObj: AboutUsModel())));
/// A notifier that manages the state of a AboutUs according to the event that is dispatched to it.
class AboutUsNotifier extends StateNotifier<AboutUsState> {AboutUsNotifier(AboutUsState state) : super(state);

 }
