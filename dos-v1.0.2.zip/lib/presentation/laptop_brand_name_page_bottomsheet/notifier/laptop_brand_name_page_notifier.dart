import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/laptop_brand_name_page_bottomsheet/models/laptop_brand_name_page_model.dart';part 'laptop_brand_name_page_state.dart';final laptopBrandNamePageNotifier = StateNotifierProvider<LaptopBrandNamePageNotifier, LaptopBrandNamePageState>((ref) => LaptopBrandNamePageNotifier(LaptopBrandNamePageState(radioGroup: '', brandName: '', laptopBrandNamePageModelObj: LaptopBrandNamePageModel(radioList: ["lbl_laptop", "lbl_computer"], radioList1: ["lbl_hp", "lbl_asus"]))));
/// A notifier that manages the state of a LaptopBrandNamePage according to the event that is dispatched to it.
class LaptopBrandNamePageNotifier extends StateNotifier<LaptopBrandNamePageState> {LaptopBrandNamePageNotifier(LaptopBrandNamePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
void changeRadioButton2(String value) { state = state.copyWith(brandName: value); } 
 }
