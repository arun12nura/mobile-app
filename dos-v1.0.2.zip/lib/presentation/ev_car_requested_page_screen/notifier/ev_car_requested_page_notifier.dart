import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/ev_car_requested_page_screen/models/ev_car_requested_page_model.dart';part 'ev_car_requested_page_state.dart';final evCarRequestedPageNotifier = StateNotifierProvider<EvCarRequestedPageNotifier, EvCarRequestedPageState>((ref) => EvCarRequestedPageNotifier(EvCarRequestedPageState(evCarRequestedPageModelObj: EvCarRequestedPageModel())));
/// A notifier that manages the state of a EvCarRequestedPage according to the event that is dispatched to it.
class EvCarRequestedPageNotifier extends StateNotifier<EvCarRequestedPageState> {EvCarRequestedPageNotifier(EvCarRequestedPageState state) : super(state);

 }
