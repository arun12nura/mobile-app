import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/ev_bike_issue_page_bottomsheet/models/ev_bike_issue_page_model.dart';part 'ev_bike_issue_page_state.dart';final evBikeIssuePageNotifier = StateNotifierProvider<EvBikeIssuePageNotifier, EvBikeIssuePageState>((ref) => EvBikeIssuePageNotifier(EvBikeIssuePageState(labelThreeController: TextEditingController(), radioGroup: '', evBikeIssuePageModelObj: EvBikeIssuePageModel(radioList: ["lbl_normal", "lbl_ev"]))));
/// A notifier that manages the state of a EvBikeIssuePage according to the event that is dispatched to it.
class EvBikeIssuePageNotifier extends StateNotifier<EvBikeIssuePageState> {EvBikeIssuePageNotifier(EvBikeIssuePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
 }
