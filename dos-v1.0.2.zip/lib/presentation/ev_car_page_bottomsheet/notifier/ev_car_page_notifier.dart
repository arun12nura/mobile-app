import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/ev_car_page_bottomsheet/models/ev_car_page_model.dart';part 'ev_car_page_state.dart';final evCarPageNotifier = StateNotifierProvider<EvCarPageNotifier, EvCarPageState>((ref) => EvCarPageNotifier(EvCarPageState(nameController: TextEditingController(), issuesController: TextEditingController(), radioGroup: '', evCarPageModelObj: EvCarPageModel(radioList: ["lbl_normal", "lbl_ev"]))));
/// A notifier that manages the state of a EvCarPage according to the event that is dispatched to it.
class EvCarPageNotifier extends StateNotifier<EvCarPageState> {EvCarPageNotifier(EvCarPageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
 }
