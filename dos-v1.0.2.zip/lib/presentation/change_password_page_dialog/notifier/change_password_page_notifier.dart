import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/change_password_page_dialog/models/change_password_page_model.dart';part 'change_password_page_state.dart';final changePasswordPageNotifier = StateNotifierProvider<ChangePasswordPageNotifier, ChangePasswordPageState>((ref) => ChangePasswordPageNotifier(ChangePasswordPageState(passwordFieldController: TextEditingController(), newPasswordFieldController: TextEditingController(), retypeNewPasswordFieldController: TextEditingController(), changePasswordPageModelObj: ChangePasswordPageModel())));
/// A notifier that manages the state of a ChangePasswordPage according to the event that is dispatched to it.
class ChangePasswordPageNotifier extends StateNotifier<ChangePasswordPageState> {ChangePasswordPageNotifier(ChangePasswordPageState state) : super(state);

 }
