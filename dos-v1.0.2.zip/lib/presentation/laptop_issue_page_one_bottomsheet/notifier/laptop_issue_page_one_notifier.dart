import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/laptop_issue_page_one_bottomsheet/models/laptop_issue_page_one_model.dart';part 'laptop_issue_page_one_state.dart';final laptopIssuePageOneNotifier = StateNotifierProvider<LaptopIssuePageOneNotifier, LaptopIssuePageOneState>((ref) => LaptopIssuePageOneNotifier(LaptopIssuePageOneState(issuesController: TextEditingController(), radioGroup: '', laptopIssuePageOneModelObj: LaptopIssuePageOneModel(radioList: ["lbl_laptop", "lbl_computer"]))));
/// A notifier that manages the state of a LaptopIssuePageOne according to the event that is dispatched to it.
class LaptopIssuePageOneNotifier extends StateNotifier<LaptopIssuePageOneState> {LaptopIssuePageOneNotifier(LaptopIssuePageOneState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
 }
