import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/bike_page_bottomsheet/models/bike_page_model.dart';part 'bike_page_state.dart';final bikePageNotifier = StateNotifierProvider<BikePageNotifier, BikePageState>((ref) => BikePageNotifier(BikePageState(nameController: TextEditingController(), issuesController: TextEditingController(), radioGroup: '', bikePageModelObj: BikePageModel())));
/// A notifier that manages the state of a BikePage according to the event that is dispatched to it.
class BikePageNotifier extends StateNotifier<BikePageState> {BikePageNotifier(BikePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
 }
