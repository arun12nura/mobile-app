// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [bike_page_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class BikePageModel extends Equatable {BikePageModel() {  }

BikePageModel copyWith() { return BikePageModel(
); } 
@override List<Object?> get props => [];
 }
