import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/profile_page_screen/models/profile_page_model.dart';part 'profile_page_state.dart';final profilePageNotifier = StateNotifierProvider<ProfilePageNotifier, ProfilePageState>((ref) => ProfilePageNotifier(ProfilePageState(profilePageModelObj: ProfilePageModel())));
/// A notifier that manages the state of a ProfilePage according to the event that is dispatched to it.
class ProfilePageNotifier extends StateNotifier<ProfilePageState> {ProfilePageNotifier(ProfilePageState state) : super(state);

 }
