import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/n_car_vendor_details_screen/models/n_car_vendor_details_model.dart';part 'n_car_vendor_details_state.dart';final nCarVendorDetailsNotifier = StateNotifierProvider<NCarVendorDetailsNotifier, NCarVendorDetailsState>((ref) => NCarVendorDetailsNotifier(NCarVendorDetailsState(nCarVendorDetailsModelObj: NCarVendorDetailsModel())));
/// A notifier that manages the state of a NCarVendorDetails according to the event that is dispatched to it.
class NCarVendorDetailsNotifier extends StateNotifier<NCarVendorDetailsState> {NCarVendorDetailsNotifier(NCarVendorDetailsState state) : super(state);

 }
