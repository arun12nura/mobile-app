import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/car_issue_page_bottomsheet/models/car_issue_page_model.dart';part 'car_issue_page_state.dart';final carIssuePageNotifier = StateNotifierProvider<CarIssuePageNotifier, CarIssuePageState>((ref) => CarIssuePageNotifier(CarIssuePageState(radioGroup: '', radioGroup1: '', carIssuePageModelObj: CarIssuePageModel(radioList: ["lbl_normal", "lbl_ev"]))));
/// A notifier that manages the state of a CarIssuePage according to the event that is dispatched to it.
class CarIssuePageNotifier extends StateNotifier<CarIssuePageState> {CarIssuePageNotifier(CarIssuePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
void changeRadioButton2(String value) { state = state.copyWith(radioGroup1: value); } 
 }
