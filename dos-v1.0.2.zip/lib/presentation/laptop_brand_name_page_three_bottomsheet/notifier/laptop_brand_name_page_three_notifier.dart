import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/laptop_brand_name_page_three_bottomsheet/models/laptop_brand_name_page_three_model.dart';part 'laptop_brand_name_page_three_state.dart';final laptopBrandNamePageThreeNotifier = StateNotifierProvider<LaptopBrandNamePageThreeNotifier, LaptopBrandNamePageThreeState>((ref) => LaptopBrandNamePageThreeNotifier(LaptopBrandNamePageThreeState(radioGroup: '', warrantyDetails: '', laptopBrandNamePageThreeModelObj: LaptopBrandNamePageThreeModel(radioList: ["lbl_laptop", "lbl_computer"], radioList1: ["msg_company_warranty", "lbl_no_warranty2"]))));
/// A notifier that manages the state of a LaptopBrandNamePageThree according to the event that is dispatched to it.
class LaptopBrandNamePageThreeNotifier extends StateNotifier<LaptopBrandNamePageThreeState> {LaptopBrandNamePageThreeNotifier(LaptopBrandNamePageThreeState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
void changeRadioButton2(String value) { state = state.copyWith(warrantyDetails: value); } 
 }
