import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:dos/presentation/referal_page_screen/models/referal_page_model.dart';
part 'referal_page_state.dart';

final referalPageNotifier =
    StateNotifierProvider<ReferalPageNotifier, ReferalPageState>(
  (ref) => ReferalPageNotifier(ReferalPageState(
    searchController: TextEditingController(),
    referalPageModelObj: ReferalPageModel(),
  )),
);

/// A notifier that manages the state of a ReferalPage according to the event that is dispatched to it.
class ReferalPageNotifier extends StateNotifier<ReferalPageState> {
  ReferalPageNotifier(ReferalPageState state) : super(state) {}
}
