import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/laptop_vendor_details_screen/models/laptop_vendor_details_model.dart';part 'laptop_vendor_details_state.dart';final laptopVendorDetailsNotifier = StateNotifierProvider<LaptopVendorDetailsNotifier, LaptopVendorDetailsState>((ref) => LaptopVendorDetailsNotifier(LaptopVendorDetailsState(laptopVendorDetailsModelObj: LaptopVendorDetailsModel())));
/// A notifier that manages the state of a LaptopVendorDetails according to the event that is dispatched to it.
class LaptopVendorDetailsNotifier extends StateNotifier<LaptopVendorDetailsState> {LaptopVendorDetailsNotifier(LaptopVendorDetailsState state) : super(state);

 }
