import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/dlete_acc_page_dialog/models/dlete_acc_page_model.dart';part 'dlete_acc_page_state.dart';final dleteAccPageNotifier = StateNotifierProvider<DleteAccPageNotifier, DleteAccPageState>((ref) => DleteAccPageNotifier(DleteAccPageState(dleteAccPageModelObj: DleteAccPageModel())));
/// A notifier that manages the state of a DleteAccPage according to the event that is dispatched to it.
class DleteAccPageNotifier extends StateNotifier<DleteAccPageState> {DleteAccPageNotifier(DleteAccPageState state) : super(state);

 }
