import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/computer_requested_page_screen/models/computer_requested_page_model.dart';part 'computer_requested_page_state.dart';final computerRequestedPageNotifier = StateNotifierProvider<ComputerRequestedPageNotifier, ComputerRequestedPageState>((ref) => ComputerRequestedPageNotifier(ComputerRequestedPageState(computerRequestedPageModelObj: ComputerRequestedPageModel())));
/// A notifier that manages the state of a ComputerRequestedPage according to the event that is dispatched to it.
class ComputerRequestedPageNotifier extends StateNotifier<ComputerRequestedPageState> {ComputerRequestedPageNotifier(ComputerRequestedPageState state) : super(state);

 }
