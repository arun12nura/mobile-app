import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/evbikebrandnamepage_item_model.dart';
import 'package:dos/presentation/ev_bike_brand_name_page_bottomsheet/models/ev_bike_brand_name_page_model.dart';
part 'ev_bike_brand_name_page_state.dart';

final evBikeBrandNamePageNotifier = StateNotifierProvider<
    EvBikeBrandNamePageNotifier, EvBikeBrandNamePageState>(
  (ref) => EvBikeBrandNamePageNotifier(EvBikeBrandNamePageState(
    evBikeBrandNamePageModelObj: EvBikeBrandNamePageModel(
        evbikebrandnamepageItemList:
            List.generate(2, (index) => EvbikebrandnamepageItemModel())),
  )),
);

/// A notifier that manages the state of a EvBikeBrandNamePage according to the event that is dispatched to it.
class EvBikeBrandNamePageNotifier
    extends StateNotifier<EvBikeBrandNamePageState> {
  EvBikeBrandNamePageNotifier(EvBikeBrandNamePageState state) : super(state) {}

  void changeRadioButton1(
    int index,
    String value,
  ) {
    List<EvbikebrandnamepageItemModel> newList =
        List<EvbikebrandnamepageItemModel>.from(
            state.evBikeBrandNamePageModelObj!.evbikebrandnamepageItemList);
    newList[index] = newList[index].copyWith(radioGroup: value);
    state = state.copyWith(
        evBikeBrandNamePageModelObj: state.evBikeBrandNamePageModelObj
            ?.copyWith(evbikebrandnamepageItemList: newList));
  }

  void changeRadioButton2(
    int index,
    String value,
  ) {
    List<EvbikebrandnamepageItemModel> newList =
        List<EvbikebrandnamepageItemModel>.from(
            state.evBikeBrandNamePageModelObj!.evbikebrandnamepageItemList);
    newList[index] = newList[index].copyWith(radioGroup1: value);
    state = state.copyWith(
        evBikeBrandNamePageModelObj: state.evBikeBrandNamePageModelObj
            ?.copyWith(evbikebrandnamepageItemList: newList));
  }
}
