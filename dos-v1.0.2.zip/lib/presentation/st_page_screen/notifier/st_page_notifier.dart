import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/st_page_screen/models/st_page_model.dart';part 'st_page_state.dart';final stPageNotifier = StateNotifierProvider<StPageNotifier, StPageState>((ref) => StPageNotifier(StPageState(stPageModelObj: StPageModel())));
/// A notifier that manages the state of a StPage according to the event that is dispatched to it.
class StPageNotifier extends StateNotifier<StPageState> {StPageNotifier(StPageState state) : super(state);

 }
