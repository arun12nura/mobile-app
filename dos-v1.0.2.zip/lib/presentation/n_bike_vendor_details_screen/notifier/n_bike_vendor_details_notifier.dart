import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/n_bike_vendor_details_screen/models/n_bike_vendor_details_model.dart';part 'n_bike_vendor_details_state.dart';final nBikeVendorDetailsNotifier = StateNotifierProvider<NBikeVendorDetailsNotifier, NBikeVendorDetailsState>((ref) => NBikeVendorDetailsNotifier(NBikeVendorDetailsState(nBikeVendorDetailsModelObj: NBikeVendorDetailsModel())));
/// A notifier that manages the state of a NBikeVendorDetails according to the event that is dispatched to it.
class NBikeVendorDetailsNotifier extends StateNotifier<NBikeVendorDetailsState> {NBikeVendorDetailsNotifier(NBikeVendorDetailsState state) : super(state);

 }
