import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/created_account_screen/models/created_account_model.dart';part 'created_account_state.dart';final createdAccountNotifier = StateNotifierProvider<CreatedAccountNotifier, CreatedAccountState>((ref) => CreatedAccountNotifier(CreatedAccountState(createdAccountModelObj: CreatedAccountModel())));
/// A notifier that manages the state of a CreatedAccount according to the event that is dispatched to it.
class CreatedAccountNotifier extends StateNotifier<CreatedAccountState> {CreatedAccountNotifier(CreatedAccountState state) : super(state);

 }
