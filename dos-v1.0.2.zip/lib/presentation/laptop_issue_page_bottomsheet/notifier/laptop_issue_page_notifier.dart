import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/laptop_issue_page_bottomsheet/models/laptop_issue_page_model.dart';part 'laptop_issue_page_state.dart';final laptopIssuePageNotifier = StateNotifierProvider<LaptopIssuePageNotifier, LaptopIssuePageState>((ref) => LaptopIssuePageNotifier(LaptopIssuePageState(radioGroup: '', radioGroup1: '', laptopIssuePageModelObj: LaptopIssuePageModel(radioList: ["lbl_laptop", "lbl_computer"]))));
/// A notifier that manages the state of a LaptopIssuePage according to the event that is dispatched to it.
class LaptopIssuePageNotifier extends StateNotifier<LaptopIssuePageState> {LaptopIssuePageNotifier(LaptopIssuePageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
void changeRadioButton2(String value) { state = state.copyWith(radioGroup1: value); } 
 }
