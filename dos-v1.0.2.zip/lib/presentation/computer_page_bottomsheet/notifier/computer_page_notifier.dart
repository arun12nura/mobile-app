import 'package:equatable/equatable.dart';import 'package:flutter/material.dart';import '/core/app_export.dart';import 'package:dos/presentation/computer_page_bottomsheet/models/computer_page_model.dart';part 'computer_page_state.dart';final computerPageNotifier = StateNotifierProvider<ComputerPageNotifier, ComputerPageState>((ref) => ComputerPageNotifier(ComputerPageState(nameController: TextEditingController(), warrantyDetailsController: TextEditingController(), issuesController: TextEditingController(), radioGroup: '', computerPageModelObj: ComputerPageModel(radioList: ["lbl_laptop", "lbl_computer"]))));
/// A notifier that manages the state of a ComputerPage according to the event that is dispatched to it.
class ComputerPageNotifier extends StateNotifier<ComputerPageState> {ComputerPageNotifier(ComputerPageState state) : super(state);

void changeRadioButton1(String value) { state = state.copyWith(radioGroup: value); } 
 }
